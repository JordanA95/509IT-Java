/**
 * 
 */
package harrisandsonsJavaPackage;

/**
 * @author Jordan Adamson
 *
 */
public interface ContactsInterface {

}
